# Basic Pages

Basic Pages is an application for Vanilla Forums that provides a way for you to create basic pages.

This application is released under the GNU GPL2 license.

## Installation

There are two ways to download this application:

1. **[Download the latest stable release](http://vanillaforums.org/get/basicpages-application).**
2. Clone the repository into the `applications` directory of Vanilla and be sure to double check that new directory is named `basicpages`.

Once you have added the application to your Vanilla installation, you need to activate it in the admin dashboard. Once activated, you will see a new "Pages" menu in the dashboard sidebar where you may start using the application.

------------------------------
Copyright © 2013 Shadowdare.