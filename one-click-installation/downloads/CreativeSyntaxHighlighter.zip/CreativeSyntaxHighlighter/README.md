![Creative Syntax Highlighter](http://creativedreams.eu/creative-syntax-highlighter/images/logo-creative-syntax-highlighter.png)

--------------------------------------------------------------------------

Vainlla Forum Plugin that adds a Code Syntax Highlighter on the discussions and comments.

It converts &lt;pre lang="php"&gt; into a php highlighted code. It supports several code languages such as php, html, css, etc.. This is based on the SyntaxHighlighter from http://alexgorbatchev.com/SyntaxHighlighter/.

--------------------------------------------------------------------------

####Plugin Page
http://creativedreams.eu/creative-syntax-highlighter/
