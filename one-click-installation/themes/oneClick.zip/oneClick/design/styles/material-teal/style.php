<?php

$StyleInfo['material-teal'] = array(
    'Name'  => 'Material Teal',
    'Description'  => 'A style based on Material Design with a colored header and footer',
    'Version'  => '1.0',
    'DateCreated' => '2015-06-19 17:48:11',
    'LastUpdate'  => '2017-01-06 21:31:47',
    'Author'  => 'Creative Dreams',
    'AuthorUrl'  => 'www.one-click-forum.com',
    'Tags'  => 'material, teal',
    'StyleEditorVersion' => '1.0',
    'System'             => true,
    'Order'              => 9
);

?>