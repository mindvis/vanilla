<div id="Foot">

    <div class="row">

        <div class="s1 m2_5">
            <img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/logo-white.png' ?>" alt="" class="responsive_img" style="margin-bottom: 16px;" />
            <p>The most Intuitive, Well Organized and Good Looking forum on the Web. It has never been so fast and easy to start giving premium support.</p>
        </div>

        <div class="s1_3 m1_5">
            <h3><?php echo T('About'); ?></h3>
            <ul>
                <li><a href="<?php echo Url('/'); ?>">Home</a></li>
                <?php if ($Session->IsValid() and $Session->CheckPermission('Garden.Settings.Manage')) { ?>
                    <li><a href="<?php echo Url('dashboard/settings'); ?>">Dashboard</a></li>
                <?php } ?>
                <li><a href="<?php echo Url('discussions'); ?>">Discussions</a></li>
                <li><a href="<?php echo Url('activity'); ?>">Activity</a></li>
                <li><a href="<?php echo Url('messages/all'); ?>">Conversations</a></li>
                <li><a href="<?php echo Url('profile'); ?>">Profile</a></li>
            </ul>
        </div>

        <div class="s1_3 m1_5">
            <h3>Information</h3>
            <ul>
                <li><a href="<?php echo Url('terms-of-use'); ?>">Terms of Use</a></li>
                <li><a href="<?php echo Url('private-policy'); ?>">Private Policy</a></li>
                <li><a href="<?php echo Url('the-team'); ?>">The Team</a></li>
                <li><a href="<?php echo Url('comunity-rules'); ?>">Community Rules</a></li>
                <li><a href="<?php echo Url('advertise'); ?>">Advertise</a></li>
            </ul>
        </div>

        <div class="s1_3 m1_5">
            <h3>One Click</h3>
            <ul>
                <li><a href="http://www.one-click-forum.com" target="product_page">Product Page</a></li>
                <li><a href="http://www.one-click-forum.com/support/documentation/" target="support">Documentation</a></li>
                <li><a href="http://www.one-click-forum.com/support/faq/" target="support">Frequently Asked Questions</a></li>
                <li><a href="http://www.one-click-forum.com/support/video-turorials/" target="support">Video Tutorials</a></li>
                <li><a href="http://www.one-click-forum.com/support/forum/" target="support">Support Forum</a></li>
                <li><a href="http://themeforest.net/item/one-click-forum/" target="buy_item">Buy Item</a></li>
            </ul>
        </div>

    </div>

</div>

<div id="SubFootWrapper">
    <div id="SubFoot">
        <div style="float: left;">
            &copy Copyright 2014 - <a href="http://www.creativedreams.eu" target="blank">Creative Dreams</a> |
            <?php echo Anchor(T('Powered by Vanilla'), C('Garden.VanillaUrl')); ?>
            <div style="font-size: 11px; opacity: 0.54;">All times are UTC</div>
        </div>
        <ul id="social" style="float: right; margin-top: 2px;">
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/envato-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/twitter-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/google-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/facebook-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/behance-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/dribbble-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/github-24.png' ?>" alt="" /></a></li>
            <li style="float: left; margin: 4px 0 4px 3px;"><a href="#" target="_blank"><img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'themes/'.C('Garden.Theme').'/design/images/rss-24.png' ?>" alt="" /></a></li>
        </ul>
    </div>
</div>