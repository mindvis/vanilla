<?php if (!defined('APPLICATION')) exit();
echo Anchor(T('New Conversation'), '/messages/add', 'Button BigButton NewConversation Primary');