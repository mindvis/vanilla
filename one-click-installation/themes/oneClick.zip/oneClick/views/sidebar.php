<!--
<div class="Box">
    <h4>Advertisement</h4>
    <div style="padding: 0;">
        <img src="<?php echo Gdn::Request()->Domain().'/'.(Gdn::Request()->WebRoot() ? Gdn::Request()->WebRoot().'/' : '').'uploads/right_banner.png' ?>" alt="" class="responsive_img" />
    </div>
</div>
-->